terraform {
  backend "azurerm" {
    resource_group_name  = "rg-launchstack-tfstate"
    storage_account_name = "stlaunchstacktf"
    container_name       = "tfstate"
    key                  = "az-aks-full/slimshield-test/prod/terraform.tfstate"
  }
}
