# az-aks-full — AKS Full-Stack

**LaunchStack stack template** | Azure | Phase 1 | **$449**

## Overview

Flagship production platform for API + Web + Worker workloads:

- Azure Kubernetes Service (AKS) + ACR
- PostgreSQL Flexible Server + Redis (private)
- Azure Key Vault + external-secrets
- API, Web (nginx SPA), and background Worker charts
- Prometheus/Grafana + Loki logging + App Insights
- GitHub Actions / Azure DevOps CI/CD (OIDC)

## Target User

Growth-stage startup shipping a containerized full-stack product with API, frontend, and async workers.

## Artifact Layout

```
stacks/az-aks-full/
├── stack.manifest.yaml          # Render engine manifest
├── launchstack.config.example.yaml
├── terraform/environments/{dev,staging,prod}/
├── helm/helmfile.yaml + helm/values/{dev,staging,prod}/
└── docs/                        # Auto-generated onboarding docs
```

## Status

| Component | Status |
|-----------|--------|
| Terraform wiring | Done |
| Helm values + helmfile | Done |
| CI/CD templates | Referenced from `cicd/` |
| Monitoring | Referenced from `monitoring/` |
| Docs templates | Done |

## Work Items

| ID | Deliverable |
|----|-------------|
| WI-118 | Stack assembly |
| WI-119 | Auto-generated docs |

## Quick Start

See `docs/DEPLOYMENT.md` after rendering with your `launchstack.config.yaml`.
