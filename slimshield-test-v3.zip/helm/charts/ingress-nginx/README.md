# ingress-nginx

LaunchStack ingress-nginx controller with cert-manager TLS integration.

## Usage

```bash
helm dependency update helm/charts/ingress-nginx
helm upgrade --install ingress-nginx helm/charts/ingress-nginx \
  --namespace ingress-nginx --create-namespace \
  -f helm/charts/ingress-nginx/values-launchstack-dev.yaml
```

## cert-manager Integration

- Ingress class `nginx` (default)
- Optional default TLS `Certificate` via `defaultTlsCertificate.enabled`
- Annotate Ingress resources: `cert-manager.io/cluster-issuer: letsencrypt-staging`

## Presets

| Preset | Service type | Default TLS |
|--------|--------------|-------------|
| `launchstack-dev` | LoadBalancer | Staging issuer |
| `launchstack-private` | LoadBalancer + Azure health probe | Production issuer |

## Work Item

| Field | Value |
|-------|-------|
| ID | WI-084 |
| Status | Done |
