# worker

LaunchStack background worker Helm chart with optional KEDA ScaledObject for queue-based autoscaling.

## Usage

```bash
helm upgrade --install worker helm/charts/worker \
  --namespace launchstack --create-namespace \
  -f helm/charts/worker/values-launchstack-dev.yaml
```

## KEDA Autoscaling

Enable Service Bus queue scaling in production:

```yaml
keda:
  enabled: true
  triggerType: azure-servicebus
  serviceBus:
    namespace: sb-launchstack-prod
    queueName: jobs
    messageCount: "10"
```

## Presets

| Preset | KEDA | Replicas |
|--------|------|----------|
| `launchstack-dev` | off | 1 |
| `launchstack-private` | Service Bus | 1–20 |

## Work Item

| Field | Value |
|-------|-------|
| ID | WI-082 |
| Status | Done |
