# Secrets Guide — slimshield-test

## Key Vault Secrets (created by user post-deploy)

| Secret name | Description | Consumed by |
|-------------|-------------|-------------|
| `database-url` | PostgreSQL connection string | API, Worker via ExternalSecret |
| `redis-url` | Redis connection string | API, Worker via ExternalSecret |
| `api-signing-key` | JWT/session signing key | API via ExternalSecret |

## Terraform-sensitive values

| Variable | Storage | Notes |
|----------|---------|-------|
| `administrator_password` | tfvars / CI secret | PostgreSQL admin — rotate after first login |

## GitHub Actions secrets

| Secret | Source |
|--------|--------|
| `AZURE_CLIENT_ID` | `terraform output github_oidc_client_id` |
| `AZURE_TENANT_ID` | `terraform output github_oidc_tenant_id` |
| `AZURE_SUBSCRIPTION_ID` | Azure portal |

## Web runtime config

The Web chart renders `config.json` at runtime from Helm values. No secrets are embedded — only the public API URL (`config.apiUrl`).

## Never commit

- `terraform.tfvars` with real passwords
- `.env` files with connection strings
- Service principal client secrets (use OIDC instead)

## Rotation

| Secret | Rotation cadence |
|--------|------------------|
| PostgreSQL password | 90 days |
| API signing key | 180 days |
| TLS certificates | Automatic via cert-manager |
