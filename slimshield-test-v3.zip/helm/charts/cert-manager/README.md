# cert-manager

LaunchStack cert-manager chart installing the upstream operator and opinionated ClusterIssuers.

## Usage

```bash
helm dependency update helm/charts/cert-manager
helm upgrade --install cert-manager helm/charts/cert-manager \
  --namespace cert-manager --create-namespace \
  -f helm/charts/cert-manager/values-launchstack-dev.yaml
```

## Presets

| Preset | ClusterIssuers |
|--------|----------------|
| `launchstack-dev` | Let's Encrypt staging |
| `launchstack-private` | Let's Encrypt production |

## Values

| Key | Description | Default |
|-----|-------------|---------|
| `operator.enabled` | Install cert-manager operator subchart | `true` |
| `clusterIssuers.letsencryptProduction.enabled` | Production ACME issuer | `false` |
| `clusterIssuers.letsencryptStaging.enabled` | Staging ACME issuer | `true` |
| `clusterIssuers.internalCa.enabled` | Internal CA issuer | `false` |

## Work Item

| Field | Value |
|-------|-------|
| ID | WI-085 |
| Status | Done |
