# external-secrets

LaunchStack external-secrets operator with Azure Key Vault ClusterSecretStore and ExternalSecret presets.

## Usage

```bash
helm dependency update helm/charts/external-secrets
helm upgrade --install external-secrets helm/charts/external-secrets \
  --namespace external-secrets --create-namespace \
  -f helm/charts/external-secrets/values-launchstack-dev.yaml
```

## Azure Key Vault

Set `secretStore.azure.vaultUrl` and workload identity annotation on `serviceAccount.annotations`:

```yaml
serviceAccount:
  annotations:
    azure.workload.identity/client-id: "<managed-identity-client-id>"
```

## Presets

| Preset | Auth | ExternalSecrets |
|--------|------|-----------------|
| `launchstack-dev` | Workload Identity | API database/redis URLs |
| `launchstack-private` | Workload Identity | 15m refresh interval |

## Work Item

| Field | Value |
|-------|-------|
| ID | WI-086 |
| Status | Done |
