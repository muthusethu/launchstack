locals {
  preset_map = {
    dev     = "launchstack-dev"
    staging = "launchstack-dev"
    prod    = "launchstack-private"
  }

  preset = local.preset_map[var.environment]

  subnet_prefixes = {
    app     = cidrsubnet(var.vnet_cidr, 8, 1)
    data    = cidrsubnet(var.vnet_cidr, 8, 2)
    ingress = cidrsubnet(var.vnet_cidr, 8, 3)
    mgmt    = cidrsubnet(var.vnet_cidr, 8, 4)
  }
}

module "naming" {
  source = "../../../../../modules/azure/foundation/azurerm-naming"

  project     = var.project
  environment = var.environment
  location    = var.location
}

module "tags" {
  source = "../../../../../modules/azure/foundation/azurerm-tags"

  project     = var.project
  environment = var.environment
  owner       = var.owner
  stack_id    = "az-aks-full"
  cost_center = var.cost_center
}

module "resource_group" {
  source = "../../../../../modules/azure/foundation/azurerm-resource-group"

  name     = module.naming.resource_group
  location = var.location
  tags     = module.tags.merged
}

module "policy" {
  source = "../../../../../modules/azure/foundation/azurerm-policy"

  scope_id          = module.resource_group.id
  location          = var.location
  preset            = "launchstack-baseline"
  allowed_locations = [var.location]
}

module "vnet" {
  source = "../../../../../modules/azure/networking/azurerm-vnet"

  name                = module.naming.virtual_network
  resource_group_name = module.resource_group.name
  location            = var.location
  address_space       = [var.vnet_cidr]
  tags                = module.tags.merged

  subnet_names = {
    app     = "snet-app"
    data    = "snet-data"
    ingress = "snet-ingress"
    mgmt    = "snet-mgmt"
  }

  subnet_prefixes = local.subnet_prefixes
}

module "managed_identity_aks" {
  source = "../../../../../modules/azure/identity/azurerm-managed-identity"

  name                = "${module.naming.managed_identity}-aks"
  resource_group_name = module.resource_group.name
  location            = var.location
  tags                = module.tags.merged
  purpose             = "aks"
}

module "key_vault" {
  source = "../../../../../modules/azure/security/azurerm-keyvault"

  name                = module.naming.key_vault
  resource_group_name = module.resource_group.name
  location            = var.location
  tags                = module.tags.merged
  preset              = local.preset
}

module "postgresql" {
  source = "../../../../../modules/azure/data/azurerm-postgresql-flexible"

  name                   = module.naming.postgresql_server
  resource_group_name    = module.resource_group.name
  location               = var.location
  tags                   = module.tags.merged
  preset                 = local.preset
  administrator_password = var.administrator_password
}

module "redis" {
  source = "../../../../../modules/azure/data/azurerm-redis"

  name                = module.naming.redis_cache
  resource_group_name = module.resource_group.name
  location            = var.location
  tags                = module.tags.merged
  preset              = local.preset
}

module "acr" {
  source = "../../../../../modules/azure/compute/azurerm-acr"

  name                = module.naming.container_registry
  resource_group_name = module.resource_group.name
  location            = var.location
  tags                = module.tags.merged
  preset              = local.preset
}

module "aks_cluster" {
  source = "../../../../../modules/azure/compute/azurerm-aks-cluster"

  name                = module.naming.aks_cluster
  resource_group_name = module.resource_group.name
  location            = var.location
  tags                = module.tags.merged
  preset              = local.preset
  dns_prefix          = "${var.project}${var.environment}"
  identity_ids        = [module.managed_identity_aks.id]
  subnet_id           = module.vnet.subnet_ids.app
  outbound_type       = var.aks_outbound_type
  sku_tier            = var.aks_sku_tier
}

module "aks_node_pool" {
  source = "../../../../../modules/azure/compute/azurerm-aks-node-pool"

  kubernetes_cluster_id = module.aks_cluster.id
  subnet_id             = module.vnet.subnet_ids.app
  preset                = var.node_pool_preset
  workload_vm_size      = var.vm_size
  workload_min_count    = var.node_count
  workload_max_count    = var.node_max_count
}

module "acr_aks_integration" {
  source = "../../../../../modules/azure/compute/azurerm-acr-aks-integration"

  enabled                     = true
  acr_id                      = module.acr.id
  kubelet_identity_object_id  = module.aks_cluster.kubelet_identity
}

module "rbac_key_vault" {
  source = "../../../../../modules/azure/identity/azurerm-rbac"

  principal_id = module.managed_identity_aks.principal_id
  preset       = "launchstack-workload"
  scopes = {
    key_vault = module.key_vault.id
  }
}

module "github_oidc" {
  source = "../../../../../modules/azure/cicd/azurerm-github-oidc"

  display_name        = "gh-oidc-${var.project}-${var.environment}"
  github_organization = var.github_organization
  github_repository   = var.github_repository
  scope_id            = module.resource_group.id
  preset              = local.preset
}

module "log_analytics" {
  source = "../../../../../modules/azure/observability/azurerm-log-analytics"

  name                = module.naming.log_analytics_workspace
  resource_group_name = module.resource_group.name
  location            = var.location
  tags                = module.tags.merged
  preset              = local.preset
}

module "app_insights" {
  source = "../../../../../modules/azure/observability/azurerm-app-insights"

  name                = module.naming.application_insights
  resource_group_name = module.resource_group.name
  location            = var.location
  workspace_id        = module.log_analytics.id
  tags                = module.tags.merged
  preset              = local.preset
}
