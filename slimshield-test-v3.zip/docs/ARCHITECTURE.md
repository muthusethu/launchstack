# Architecture — slimshield-test

## Overview

The **az-aks-full** stack deploys a production-ready full-stack platform on Azure Kubernetes Service with API, Web frontend, background Workers, managed PostgreSQL, Redis, and full observability (metrics + logs).

## Component Diagram

```mermaid
flowchart TB
    subgraph Internet
        Users[Web Users]
        APIClients[API Clients]
        GH[GitHub Actions]
    end

    subgraph Azure
        ACR[Container Registry]
        AKS[AKS Cluster]
        PG[(PostgreSQL)]
        Redis[(Redis)]
        KV[Key Vault]
        AI[App Insights]
        LA[Log Analytics]
    end

    subgraph AKS Workloads
        Web[Web nginx SPA]
        API[API Service]
        Worker[Background Worker]
        Prom[Prometheus/Grafana]
        Loki[Loki]
    end

    Users -->|HTTPS| Web
    APIClients -->|HTTPS| API
    Web -->|API calls| API
    GH -->|OIDC push| ACR
    ACR -->|pull| AKS
    API --> PG
    API --> Redis
    Worker --> Redis
    Worker --> PG
    API -->|external-secrets| KV
    Worker -->|external-secrets| KV
    AKS --> AI
    AI --> LA
    API --> Prom
    Worker --> Loki
    API --> Loki
```

## Network Layout

| Subnet | Purpose |
|--------|---------|
| snet-app | AKS nodes |
| snet-data | PostgreSQL, Redis private endpoints |
| snet-ingress | Ingress load balancer |
| snet-mgmt | Management |

VNet CIDR: `172.16.0.0/16`

## Workloads

| Workload | Chart | Namespace | Ingress |
|----------|-------|-----------|---------|
| API | `helm/charts/api` | `launchstack` | `api.slimshieldv3.com` |
| Web | `helm/charts/web` | `launchstack` | `app.slimshieldv3.com` |
| Worker | `helm/charts/worker` | `launchstack` | Internal only |
| Ingress | `ingress-nginx` | `ingress-nginx` | — |
| TLS | `cert-manager` | `cert-manager` | — |
| Metrics | `kube-prometheus-stack` | `monitoring` | — |
| Logs | `loki-stack` | `logging` | — |

## Identity

| Identity | Purpose |
|----------|---------|
| AKS managed identity | Key Vault access, Azure RBAC |
| GitHub OIDC SP | CI/CD — ACR push, AKS deploy |
| Workload identity | Per-pod Key Vault secret sync |

## Observability

| Signal | Stack | Dashboards |
|--------|-------|------------|
| Metrics | Prometheus + Grafana | api-golden-signals, kubernetes-cluster, postgresql, redis |
| Logs | Loki | Grafana Explore |
| Traces | App Insights | Azure portal |
| Alerts | PrometheusRules | api-alerts, infra-alerts, slo-burn-rate |
| Cost | Azure Cost Management | cost-overview, cicd |
