# api

LaunchStack main HTTP API Helm chart with Deployment, Service, HPA, PDB, Ingress, and observability hooks.

## Usage

```bash
helm upgrade --install api helm/charts/api \
  --namespace launchstack --create-namespace \
  -f helm/charts/api/values-launchstack-dev.yaml
```

## Features

- Dedicated ServiceAccount with Azure Workload Identity annotations
- HTTP liveness/readiness probes (configurable paths)
- Ingress with cert-manager TLS
- Optional HPA, PDB, ExternalSecret, ServiceMonitor
- Security baseline: non-root, read-only root FS, dropped capabilities

## Presets

| Preset | Replicas | HPA | PDB | ExternalSecrets |
|--------|----------|-----|-----|-----------------|
| `launchstack-dev` | 1 | off | off | on |
| `launchstack-private` | 2+ | on | on | on (15m refresh) |

## Work Item

| Field | Value |
|-------|-------|
| ID | WI-081 |
| Status | Done |
