# web

LaunchStack frontend SPA Helm chart (nginx) with runtime `config.json` ConfigMap and ingress.

## Usage

```bash
helm upgrade --install web helm/charts/web \
  --namespace launchstack --create-namespace \
  -f helm/charts/web/values-launchstack-dev.yaml
```

## Features

- nginx Deployment serving static SPA assets
- ConfigMap injects `/config.json` at deploy time (API URL, environment)
- Custom nginx `default.conf` for SPA routing (`try_files` → `index.html`)
- Ingress with cert-manager TLS
- Optional HPA, PDB, topology spread
- Security baseline: non-root (UID 101), read-only root FS, dropped capabilities

## Runtime Config

The SPA fetches `/config.json` at startup. Values are rendered from `runtimeConfig`:

```yaml
runtimeConfig:
  apiUrl: "https://api.example.com"
  environment: development
  extra:
    featureFlagsUrl: "https://api.example.com/flags"
```

## Presets

| Preset | Replicas | HPA | PDB | Topology spread |
|--------|----------|-----|-----|-----------------|
| `launchstack-dev` | 1 | off | off | off |
| `launchstack-private` | 2+ | on | on | on |

## Documented Exceptions

| Exception | Reason |
|-----------|--------|
| `runAsUser: 101` | Official nginx unprivileged image requires UID/GID 101 |

## Work Item

| Field | Value |
|-------|-------|
| ID | WI-083 |
| Status | Done |
