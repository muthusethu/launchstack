# Troubleshooting — slimshield-test

## API not reachable

1. Check ingress: `kubectl get ingress -n launchstack`
2. Verify DNS points to ingress LB IP
3. Check cert-manager: `kubectl describe certificate api-tls -n launchstack`
4. Test pod health: `kubectl port-forward svc/api -n launchstack 8080:80`

## Web app blank or wrong API URL

1. Check `config.json`: `kubectl exec -n launchstack deploy/web -- cat /usr/share/nginx/html/config.json`
2. Verify `config.apiUrl` in `helm/values/<env>/web.yaml`
3. Confirm CORS settings on API allow `app.slimshieldv3.com`

## Worker not processing jobs

1. Check worker logs: `kubectl logs -n launchstack -l app.kubernetes.io/name=worker`
2. Verify Redis connectivity and `redis-url` secret
3. If KEDA enabled: `kubectl get scaledobject -n launchstack`
4. Confirm queue name matches `worker-queue` in Helm values

## Image pull failures

1. Verify ACR integration: `az role assignment list --scope <acr_id>`
2. Check images exist: `az acr repository list -n <acr_name>`
3. Confirm `image.repository` in Helm values matches ACR login server

## ExternalSecret not syncing

1. Check SecretStore: `kubectl get clustersecretstore`
2. Verify workload identity annotation on ESO service account
3. Review ESO logs: `kubectl logs -n external-secrets -l app.kubernetes.io/name=external-secrets`

## Loki not receiving logs

1. Check loki-stack pods: `kubectl get pods -n logging`
2. Verify Promtail DaemonSet: `kubectl get ds -n logging`
3. Confirm Grafana Loki datasource in kube-prometheus-stack values

## Database connection errors

1. Confirm `database-url` secret in Key Vault
2. Check PostgreSQL firewall / private endpoint connectivity
3. Test from debug pod: `kubectl run pgtest --rm -it --image=postgres:16 -- psql "<connection_string>"`

## CI/CD OIDC failures

1. Verify federated credential subject matches repo and branch
2. Confirm `AZURE_CLIENT_ID` / `AZURE_TENANT_ID` secrets
3. Check SP has AcrPush and AKS cluster user role on resource group

## Terraform apply errors

1. Run `terraform plan` in isolation first
2. Check Azure Policy denies in Activity Log
3. Verify naming limits (ACR, Key Vault global uniqueness)
