# launchstack-policies

LaunchStack Kubernetes security baseline applied per workload namespace.

## Usage

Apply before workload charts (`api`, `web`, `worker`):

```bash
helm upgrade --install launchstack-policies helm/policies \
  --namespace launchstack --create-namespace \
  -f helm/policies/values-launchstack-dev.yaml
```

Label an existing namespace for Pod Security Standards (if `createNamespace: false`):

```bash
kubectl label namespace launchstack \
  pod-security.kubernetes.io/enforce=restricted \
  pod-security.kubernetes.io/audit=restricted \
  pod-security.kubernetes.io/warn=restricted \
  --overwrite
```

## Baseline Controls

| Control | Implementation |
|---------|----------------|
| Pod Security Standards | Namespace labels: `restricted` enforce/audit/warn |
| Network policies | Default deny all; allow DNS, same-namespace, ingress-nginx |
| Resource quotas | Per-namespace CPU/memory/pod limits |
| Limit ranges | Default container requests/limits and max bounds |
| Topology spread | Enforced in workload charts (`api`, `web`, `worker`) |

## Documented Exceptions

| Exception | Workload | Reason |
|-----------|----------|--------|
| `runAsUser: 101` | `web` | nginx unprivileged image requires UID/GID 101 |
| `readOnlyRootFilesystem: false` | `ingress-nginx` | Upstream controller requires writable paths |
| Prometheus scrape ingress | `launchstack-private` | Allow monitoring namespace → workload metrics ports |

Add namespace-specific overrides via `networkPolicy.additionalRules` only when required.

## Presets

| Preset | Quota scale | Extra rules |
|--------|-------------|-------------|
| `launchstack-dev` | Small (10 CPU / 20Gi) | Deny-all + DNS + ingress |
| `launchstack-private` | Production (40 CPU / 80Gi) | + Prometheus scrape from `monitoring` NS |

## Work Item

| Field | Value |
|-------|-------|
| ID | WI-089 |
| Status | Done |
