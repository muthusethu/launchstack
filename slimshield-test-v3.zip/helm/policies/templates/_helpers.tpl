{{- define "policies.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "policies.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name (include "policies.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "policies.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "policies.labels" -}}
helm.sh/chart: {{ include "policies.chart" . }}
app.kubernetes.io/name: {{ include "policies.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: launchstack
launchstack.io/environment: {{ .Values.global.environment | quote }}
launchstack.io/project: {{ .Values.global.project | quote }}
{{- end -}}

{{- define "policies.namespace" -}}
{{- .Values.namespace | trunc 63 | trimSuffix "-" -}}
{{- end -}}
