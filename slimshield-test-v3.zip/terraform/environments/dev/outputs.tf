output "resource_group_name" {
  description = "Primary resource group name."
  value       = module.resource_group.name
}

output "aks_cluster_name" {
  description = "AKS cluster name."
  value       = module.aks_cluster.name
}

output "aks_oidc_issuer_url" {
  description = "AKS OIDC issuer URL for workload identity federation."
  value       = module.aks_cluster.oidc_issuer_url
}

output "acr_login_server" {
  description = "ACR login server for CI/CD image push."
  value       = module.acr.login_server
}

output "key_vault_uri" {
  description = "Key Vault URI for secret storage."
  value       = module.key_vault.vault_uri
}

output "postgresql_fqdn" {
  description = "PostgreSQL flexible server FQDN."
  value       = module.postgresql.fqdn
}

output "redis_hostname" {
  description = "Redis cache hostname."
  value       = module.redis.hostname
}

output "github_oidc_client_id" {
  description = "GitHub Actions OIDC client ID."
  value       = module.github_oidc.client_id
}

output "github_oidc_tenant_id" {
  description = "Azure AD tenant ID for GitHub OIDC."
  value       = module.github_oidc.tenant_id
}

output "app_insights_connection_string" {
  description = "Application Insights connection string."
  value       = module.app_insights.connection_string
  sensitive   = true
}

output "log_analytics_workspace_id" {
  description = "Log Analytics workspace ID."
  value       = module.log_analytics.id
}
