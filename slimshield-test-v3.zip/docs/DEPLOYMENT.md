# Deployment Guide — slimshield-test

## Prerequisites

- Azure subscription with Contributor access
- Terraform 1.9.8+
- Helm 3.16+ and helmfile
- `kubectl` and `az` CLI
- GitHub repository with Actions enabled (monorepo or multi-repo)

## Step 1 — Bootstrap Terraform state

Create remote state storage (one-time):

```bash
az group create -n rg-launchstack-tfstate -l eastus
az storage account create -n stlaunchstacktf -g rg-launchstack-tfstate -l eastus --sku Standard_LRS
az storage container create -n tfstate --account-name stlaunchstacktf
```

## Step 2 — Deploy infrastructure

```bash
cd terraform/environments/dev
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your values
terraform init
terraform plan
terraform apply
```

Save outputs — required for Helm and CI/CD configuration.

## Step 3 — Configure Key Vault secrets

```bash
az keyvault secret set --vault-name <key_vault_name> --name database-url --value "postgresql://..."
az keyvault secret set --vault-name <key_vault_name> --name redis-url --value "redis://..."
az keyvault secret set --vault-name <key_vault_name> --name api-signing-key --value "<random-key>"
```

See `docs/SECRETS.md` for the full secret catalog.

## Step 4 — Install Helm platform stack

```bash
az aks get-credentials -g <resource_group> -n <aks_cluster_name>
cd helm
helmfile -e dev apply
```

Deploy order: cert-manager → ingress → external-secrets → prometheus → loki → policies → api → web → worker.

## Step 5 — Configure CI/CD

Set GitHub repository secrets from Terraform outputs:

| Secret | Output |
|--------|--------|
| `AZURE_CLIENT_ID` | `github_oidc_client_id` |
| `AZURE_TENANT_ID` | `github_oidc_tenant_id` |
| `AZURE_SUBSCRIPTION_ID` | Your subscription ID |

Copy rendered workflows from `cicd/github-actions/` to `.github/workflows/`. Ensure CI builds all three images (`api`, `web`, `worker`) and pushes to ACR.

## Step 6 — Verify

```bash
curl -fsS https://api.slimshieldv3.com/healthz
curl -fsS https://app.slimshieldv3.com/
kubectl get pods -n launchstack
kubectl get pods -n logging
```

## Step 7 — Import monitoring dashboards

Import Grafana dashboards from `monitoring/dashboards/` and apply alert rules from `monitoring/alerts/`.
