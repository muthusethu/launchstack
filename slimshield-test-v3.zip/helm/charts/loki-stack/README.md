# loki-stack

LaunchStack logging chart installing Loki and Promtail. Optional Pro-tier add-on when cloud-native logging is insufficient.

## Usage

```bash
helm dependency update helm/charts/loki-stack
helm upgrade --install loki-stack helm/charts/loki-stack \
  --namespace logging --create-namespace \
  -f helm/charts/loki-stack/values-launchstack-dev.yaml
```

Install after `kube-prometheus-stack` when enabling Loki metrics scraping.

## Features

- Loki log aggregation with Promtail DaemonSet
- Grafana/Prometheus bundled charts disabled (use kube-prometheus-stack)
- CRI log parsing pipeline
- Optional `ServiceMonitor` for Prometheus scraping
- 7-day retention (dev) / 30-day retention (private preset)

## Presets

| Preset | Persistence | Retention | ServiceMonitor |
|--------|-------------|-----------|----------------|
| `launchstack-dev` | off | 7d | off |
| `launchstack-private` | 50Gi | 30d | on |

## Tier

| Tier | Logging default |
|------|-----------------|
| Starter / Growth | Azure Monitor / Log Analytics |
| Pro+ | Optional `loki-stack` Helm chart |

## Work Item

| Field | Value |
|-------|-------|
| ID | WI-088 |
| Status | Done |
