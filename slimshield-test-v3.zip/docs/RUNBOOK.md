# Runbook — slimshield-test

## On-call contacts

| Role | Contact |
|------|---------|
| Platform owner | platform-team |
| Alert email | muthu-v3@slimshield.com |

## Common operations

### Scale API replicas

```bash
kubectl scale deployment api -n launchstack --replicas=3
helm upgrade api helm/charts/api -n launchstack --reuse-values --set replicaCount=3
```

### Scale Web replicas

```bash
kubectl scale deployment web -n launchstack --replicas=3
```

### Scale Worker replicas (manual, when KEDA disabled)

```bash
kubectl scale deployment worker -n launchstack --replicas=3
```

### Rollback deployment

```bash
helm rollback api -n launchstack
helm rollback web -n launchstack
helm rollback worker -n launchstack
```

### Restart all workload pods

```bash
kubectl rollout restart deployment/api deployment/web deployment/worker -n launchstack
```

### Check certificate expiry

```bash
kubectl get certificate -A
kubectl describe certificate api-tls web-tls -n launchstack
```

### Query logs in Grafana

1. Open Grafana → Explore → Loki
2. Filter: `{namespace="launchstack", app="api"}` or `app="worker"`

## Alert response

| Alert | Action |
|-------|--------|
| ApiHighErrorRate | Check API logs in Loki; review recent deploys |
| PodCrashLooping | `kubectl logs` + `kubectl describe pod` |
| CertExpiringSoon | Verify cert-manager ClusterIssuer; check DNS |
| PostgresConnectionsHigh | Review connection pool settings; scale DB SKU |
| SloBurnRateHigh | Check error budget dashboard; consider rollback |
| WorkerQueueBacklog | Scale worker replicas or verify KEDA ScaledObject |

## Maintenance windows

- **dev**: Anytime
- **staging**: Business hours
- **prod**: Sunday 02:00–04:00 eastus (scheduled)
