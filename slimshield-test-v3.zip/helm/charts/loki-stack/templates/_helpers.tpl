{{- define "launchstack.labels" -}}
app.kubernetes.io/name: {{ include "launchstack.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: launchstack
helm.sh/chart: {{ include "launchstack.chart" . }}
launchstack.io/environment: {{ .Values.global.environment | quote }}
launchstack.io/project: {{ .Values.global.project | quote }}
{{- with .Values.global.additionalLabels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{- define "launchstack.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "launchstack.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
