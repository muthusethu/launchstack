variable "project" {
  description = "Project name slug."
  type        = string
}

variable "environment" {
  description = "Environment name: dev, staging, prod."
  type        = string

  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment must be dev, staging, or prod."
  }
}

variable "location" {
  description = "Azure region."
  type        = string
}

variable "owner" {
  description = "Resource owner tag."
  type        = string
  default     = "platform-team"
}

variable "cost_center" {
  description = "Cost center tag."
  type        = string
  default     = "engineering"
}

variable "vnet_cidr" {
  description = "Virtual network CIDR block."
  type        = string
  default     = "10.0.0.0/16"
}

variable "administrator_password" {
  description = "PostgreSQL administrator password (store in Key Vault post-deploy)."
  type        = string
  sensitive   = true
}

variable "github_organization" {
  description = "GitHub organization or user for OIDC."
  type        = string
}

variable "github_repository" {
  description = "GitHub repository name for OIDC."
  type        = string
}

variable "aks_outbound_type" {
  description = "AKS outbound type."
  type        = string
  default     = "loadBalancer"
}

variable "aks_sku_tier" {
  description = "AKS SKU tier."
  type        = string
  default     = "Free"
}

variable "node_pool_preset" {
  description = "AKS node pool preset."
  type        = string
  default     = "launchstack-workload"
}

variable "node_count" {
  description = "Minimum node count for workload pool."
  type        = number
  default     = 1
}

variable "node_max_count" {
  description = "Maximum node count for workload pool."
  type        = number
  default     = 3
}

variable "vm_size" {
  description = "AKS node VM size."
  type        = string
  default     = "Standard_D2s_v5"
}
