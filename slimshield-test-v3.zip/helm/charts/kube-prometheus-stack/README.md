# kube-prometheus-stack

LaunchStack monitoring chart installing the upstream kube-prometheus-stack operator with LaunchStack alert rules and Grafana dashboards.

## Usage

```bash
helm dependency update helm/charts/kube-prometheus-stack
helm upgrade --install kube-prometheus-stack helm/charts/kube-prometheus-stack \
  --namespace monitoring --create-namespace \
  -f helm/charts/kube-prometheus-stack/values-launchstack-dev.yaml
```

Install after `cert-manager` and before workload charts that expose `ServiceMonitor` resources.

## Features

- Prometheus + Grafana + Alertmanager via upstream subchart
- LaunchStack `PrometheusRule` alerts (API golden signals, infra)
- Pre-built Grafana dashboards (API, Kubernetes cluster)
- Optional Grafana Ingress with cert-manager TLS
- ServiceMonitor discovery for all namespaces (`selectorNilUsesHelmValues: false`)

## Presets

| Preset | Retention | Grafana ingress | API error threshold |
|--------|-----------|-----------------|---------------------|
| `launchstack-dev` | 7d | off | 5% |
| `launchstack-private` | 30d | on (prod TLS) | 1% |

## Workload Integration

Enable `serviceMonitor` in the `api` chart and set:

```yaml
serviceMonitor:
  enabled: true
  labels:
    release: kube-prometheus-stack
```

## Work Item

| Field | Value |
|-------|-------|
| ID | WI-087 |
| Status | Done |
